const jwt = require("jsonwebtoken");
const Workshop = require("../models/Workshop");
const User = require("../models/User");
const ExcelJS = require("exceljs");
const nodemailer = require("nodemailer");
const { unregisterUserFromWorkshop, unregisterFamilyFromWorkshop ,registerFamilyToWorkshop,registerUserToWorkshop} =
  require("../services/workshopRegistration");
const mongoose = require("mongoose");

/* ============================================================
   🔍 Workshop Search Helpers
   ============================================================ */


// Normalize the search query: lowercase, trim and remove unwanted chars
function normalizeWorkshopQuery(q) {
  return String(q || "")
    .trim()
    .toLowerCase()
    .replace(/[^\w@.\s\u0590-\u05FF]/g, "");
}
/* ------------------------------------------------------------
   🔧 Internal helper: automatically promote from the waiting list
------------------------------------------------------------ */
async function autoPromoteFromWaitlist(workshop) {
  try {
    let promoted = false;
    // Loop while there is space and entries waiting
    while (workshop.canAddParticipant() && Array.isArray(workshop.waitingList) && workshop.waitingList.length > 0) {
      const entry = workshop.waitingList.shift();
      if (!entry) break;
      // If we have a familyMemberId then this is a family registration
      if (entry.familyMemberId) {
        workshop.familyRegistrations.push({
          parentUser: entry.parentUser,
          familyMemberId: entry.familyMemberId,
          name: entry.name,
          relation: entry.relation,
          idNumber: entry.idNumber,
          phone: entry.phone,
          birthDate: entry.birthDate,
        });
      } else {
        // Otherwise treat as a main user registration
        workshop.participants.push(entry.parentUser);
      }
      promoted = true;
    }
    if (promoted) {
      // Save once if we made changes
      await workshop.save();
    }
  } catch (err) {
    console.error("⚠️ autoPromoteFromWaitlist error:", err);
  }
}
/**
 * ============================================================
 * Workshop Controller (Clean Version)
 * ============================================================
 * - Unified user + family registration.
 * - Auto-detect user if Authorization header exists.
 * - Populates all participant info including idNumber.
 */

/* ------------------------------------------------------------
   🧩 Helper: attach user if token provided (optional auth)
------------------------------------------------------------ */
async function attachUserIfPresent(req) {
  try {
    const auth = req.headers?.authorization || "";
    if (!auth.startsWith("Bearer ")) return;
    const token = auth.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id || decoded.userId;
    if (!userId) return;
    const user = await User.findById(userId).select("_id role name email");
    if (user) req.user = user;
  } catch (err) {
  }
}



// controllers/workshopController.js
const escapeRegex = (s = "") => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

exports.getAllWorkshops = async (req, res) => {
  try {
    // If this route can be called without auth, but you still want per-user flags:
    // await attachUserIfPresent(req); // uncomment if not already attached by middleware

    // --- pagination ---
    const page  = Math.max(1, parseInt(req.query.page  || "1", 10));
    const limit = Math.max(1, Math.min(parseInt(req.query.limit || "60", 10), 200));
    const skip  = (page - 1) * limit;

    const amount       = parseInt(req.query.amount || "0", 10);
    const previewLimit = amount > 0 ? Math.min(amount, 12) : null;
    const limitToUse   = previewLimit || limit;
    const skipToUse    = previewLimit ? 0 : skip;

    // --- filters (USE THIS ONE VARIABLE EVERYWHERE) ---
    const filters = {};
    if (req.query.city)     filters.city     = { $regex: new RegExp(escapeRegex(req.query.city), "i") };
    if (req.query.type)     filters.type     = req.query.type;
    if (req.query.coach)    filters.coach    = { $regex: new RegExp(escapeRegex(req.query.coach), "i") };
    if (req.query.ageGroup) filters.ageGroup = req.query.ageGroup;
    if (req.query.day)      filters.days     = req.query.day;
    if (req.query.available !== undefined) {
      const v = String(req.query.available).toLowerCase();
      if (v === "true" || v === "false") filters.available = (v === "true");
    }

    // --- projection: include everything WorkshopCard / page needs ---
    const projection = {
      title: 1,
      type: 1,
      ageGroup: 1,
      city: 1,
      address: 1,
      studio: 1,
      coach: 1,
      days: 1,
      hour: 1,
      sessionsCount: 1,
      startDate: 1,
      endDate: 1,
      inactiveDates: 1,
      available: 1,
      description: 1,
      price: 1,
      image: 1,
      participants: 1,
      familyRegistrations: 1,
      waitingList: 1,
      waitingListMax: 1,
      participantsCount: 1,
      maxParticipants: 1,
    };

    const [docs, totalCount] = await Promise.all([
      Workshop.find(filters)
        .select(projection)
        .sort({ startDate: 1 })
        .skip(skipToUse)
        .limit(limitToUse)
        .lean(),
      Workshop.countDocuments(filters),
    ]);

    // --- enrich with per-user flags if authenticated ---
    const userId = req.user?._id?.toString?.();
    const enriched = userId
      ? docs.map((w) => {
          const participants = Array.isArray(w.participants) ? w.participants : [];
          const familyRegs   = Array.isArray(w.familyRegistrations) ? w.familyRegistrations : [];

          const direct    = participants.some((p) => p?.toString?.() === userId);
          const viaFamily = familyRegs.some((fr) => fr?.parentUser?.toString?.() === userId);

          const userFamilyRegistrations = familyRegs
            .filter((fr) => fr?.parentUser?.toString?.() === userId)
            .map((fr) => fr?.familyMemberId?.toString?.())
            .filter(Boolean);

          const participantsCount =
            typeof w.participantsCount === "number"
              ? w.participantsCount
              : (participants.length + familyRegs.length);

          return {
            ...w,
            // safe defaults
            address: w.address || "",
            city: w.city || "",
            studio: w.studio || "",
            coach: w.coach || "",
            waitingList: Array.isArray(w.waitingList) ? w.waitingList : [],
            maxParticipants: Number(w.maxParticipants ?? 0),
            waitingListMax: Number(w.waitingListMax ?? 0),
            participantsCount,
            isUserRegistered: Boolean(direct || viaFamily),
            userFamilyRegistrations,
          };
        })
      : docs;

    // --- meta ---
    const totalPages = Math.ceil(totalCount / limit);
    const baseUrl =
      process.env.FRONTEND_BASE_URL ||
      `${req.protocol}://${req.get("host")}${req.baseUrl || "/api/workshops"}`;

    return res.json({
      meta: {
        totalCount,
        totalPages,
        currentPage: page,
        limit,
        returned: enriched.length,
        preview: Boolean(previewLimit),
        nextPage: page < totalPages ? `${baseUrl}?page=${page + 1}&limit=${limit}` : null,
        prevPage: page > 1 ? `${baseUrl}?page=${page - 1}&limit=${limit}` : null,
      },
      data: enriched,
    });
  } catch (err) {
    console.error("❌ [getAllWorkshops] Error:", err);
    res.status(500).json({ message: "Server error fetching workshops", error: err.message });
  }
};

/* ------------------------------------------------------------
   🧩 GET /api/workshops/registered
   ------------------------------------------------------------
   Returns an array of workshop IDs for which the authenticated user
   is directly registered.  Previously this endpoint also returned
   workshops where a family member was registered, which led the
   frontend to incorrectly mark the user as registered for workshops
   they were not actually enrolled in.  To avoid this confusion
   the logic now only checks the participants array.  Family
   registrations remain accessible via the `userFamilyRegistrations`
   field returned from the `getAllWorkshops` endpoint.
------------------------------------------------------------ */
exports.getRegisteredWorkshops = async (req, res) => {
  try {
    // Ensure the request is authenticated.  The auth middleware
    // attaches `req.user`; if it is missing then the user is
    // unauthorized.
    const userId = req.user?._id?.toString();
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Only select workshops where the user is a direct participant.
    // Do not include workshops where the user only has a family
    // member registered.  This prevents the frontend from treating
    // those workshops as if the user themself were registered.
    const list = await Workshop.find({ participants: userId }).select(
      "_id"
    );
    const ids = list.map((w) => w._id.toString());
    return res.json(ids);
  } catch (err) {
    console.error(
      "❌ Error fetching registered workshops (participants only):",
      err
    );
    return res
      .status(500)
      .json({ message: "Server error fetching registrations" });
  }
};

/* ------------------------------------------------------------
   🟢 GET /api/workshops/:id
------------------------------------------------------------ */
/**
 * @desc Get a single workshop by ID (populated & lean)
 * @route GET /api/workshops/:id
 * @access Authenticated (admin or user)
 */
exports.getWorkshopById = async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || !mongoose.isValidObjectId(id)) {
      return res.status(400).json({ message: "Invalid workshop ID" });
    }

    const workshop = await Workshop.findById(id)
      .populate("participants", "name email idNumber phone city")
      .populate("familyRegistrations.parentUser", "name email idNumber phone city")
      .populate("familyRegistrations.familyMemberId", "name relation idNumber phone birthDate city")
      .populate("waitingList.parentUser", "name email")
      .lean();

    if (!workshop) {
      return res.status(404).json({ message: "Workshop not found" });
    }

    // 🧩 Normalize optional fields to prevent UI crashes
    const normalized = {
      ...workshop,
      address: workshop.address || "",
      city: workshop.city || "",
      studio: workshop.studio || "",
      coach: workshop.coach || "",
      participantsCount:
        workshop.participantsCount ??
        ((workshop.participants?.length || 0) +
          (workshop.familyRegistrations?.length || 0)),
    };

    // 🕓 Attach derived meta info
    normalized.meta = {
      totalParticipants: normalized.participantsCount,
      waitingListCount: workshop.waitingList?.length || 0,
      isAvailable: !!workshop.available,
    };

    // ✅ Return clean normalized payload
    return res.json({ success: true, data: normalized });
  } catch (err) {
    console.error("❌ [getWorkshopById] Error:", err.message);
    return res.status(500).json({ message: "Server error fetching workshop" });
  }
};



/* ------------------------------------------------------------
   🟡 POST /api/workshops  (Admin)
   ------------------------------------------------------------
   Creates a new workshop with support for:
   - Multiple meeting days (days[])
   - sessionsCount replacing weeksDuration
   - Auto-calculated endDate based on sessionsCount & startDate
   - Optional inactiveDates (holidays)
------------------------------------------------------------ */
/**
 * @desc Update a workshop (with auto endDate + safe address validation)
 * @route PUT /api/workshops/:id
 * @access Admin only
 */
exports.updateWorkshop = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ message: "Invalid workshop ID" });
    }

    const existing = await Workshop.findById(id);
    if (!existing) {
      return res.status(404).json({ message: "Workshop not found" });
    }

    /* ============================================================
       🧩 Define allowed fields for update
       ============================================================ */
    const allowed = [
      "title", "type", "ageGroup", "city", "address", "studio", "coach",
      "days", "hour", "available", "description", "price",
      "image", "maxParticipants", "waitingListMax", "autoEnrollOnVacancy",
      "sessionsCount", "startDate", "inactiveDates"
    ];

    const updates = {};
    for (const key of allowed) {
      if (key in req.body) updates[key] = req.body[key];
    }

    /* ============================================================
       🌍 Address validation (non-blocking)
       ============================================================ */
    if ("city" in updates || "address" in updates) {
      const city = updates.city ?? existing.city;
      const address = updates.address ?? existing.address;

      if (!city || !address) {
        return res.status(400).json({
          message: "City and address are required for update",
        });
      }

      const checkAddress = async () => {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 2500);
          const url = `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(
            city
          )}&street=${encodeURIComponent(address)}&country=Israel&format=json`;

          const resp = await fetch(url, {
            signal: controller.signal,
            headers: { "User-Agent": "Clalit-Workshops-App" },
          });
          clearTimeout(timeout);
          const result = await resp.json();

          if (!Array.isArray(result) || result.length === 0) {
            console.warn(`⚠ Address not found for city "${city}" — saving anyway`);
          }
        } catch (err) {
          console.warn("⚠ Address validation service unavailable — skipping check");
        }
      };
      checkAddress().catch(() => {});
    }

    /* ============================================================
       🗓 Days + inactiveDates normalization
       ============================================================ */
    const daysMap = {
      ראשון: "Sunday",
      שני: "Monday",
      שלישי: "Tuesday",
      רביעי: "Wednesday",
      חמישי: "Thursday",
      שישי: "Friday",
      שבת: "Saturday",
    };

    if (updates.days) {
      updates.days = Array.isArray(updates.days) ? updates.days : [updates.days];
      updates.days = updates.days
        .map((d) => daysMap[d] || d)
        .filter((d) =>
          ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].includes(d)
        );
    }

    if (updates.inactiveDates) {
      updates.inactiveDates = Array.isArray(updates.inactiveDates)
        ? updates.inactiveDates
        : [updates.inactiveDates];
      updates.inactiveDates = updates.inactiveDates
        .map((d) => new Date(d))
        .filter((d) => !isNaN(d.getTime()));
    }

    if (updates.sessionsCount && isNaN(updates.sessionsCount)) {
      return res.status(400).json({ message: "sessionsCount must be numeric" });
    }

    /* ============================================================
       💾 Apply update and re-run schema hooks (for endDate)
       ============================================================ */
    Object.assign(existing, updates);

    // Force recalculation of endDate if key fields changed
    if ("startDate" in updates || "days" in updates || "sessionsCount" in updates) {
      existing.markModified("startDate");
      existing.markModified("days");
      existing.markModified("sessionsCount");
    }

    await existing.save();

    /* ============================================================
       📦 Reload normalized + populated data
       ============================================================ */
    const ws = await Workshop.findById(existing._id)
      .populate("participants", "name email idNumber phone city")
      .populate("familyRegistrations.parentUser", "name email idNumber phone city")
      .populate("familyRegistrations.familyMemberId", "name relation idNumber phone birthDate city")
      .populate("waitingList.parentUser", "name email")
      .lean();

    const normalized = {
      ...ws,
      address: ws.address || "",
      city: ws.city || "",
      studio: ws.studio || "",
      coach: ws.coach || "",
    };

    const meta = {
      totalParticipants:
        (ws.participants?.length || 0) + (ws.familyRegistrations?.length || 0),
      waitingListCount: ws.waitingList?.length || 0,
      available: !!ws.available,
    };

    console.log("✅ Workshop updated:", {
      title: ws.title,
      city: ws.city,
      startDate: ws.startDate,
      endDate: ws.endDate,
    });

    return res.json({
      success: true,
      message: "Workshop updated successfully",
      data: normalized,
      meta,
    });
  } catch (err) {
    console.error("❌ [updateWorkshop] Error:", err);
    return res.status(500).json({
      message: err.message || "Failed to update workshop",
    });
  }
};



/**
 * @desc Create a new workshop (with non-blocking address validation)
 * @route POST /api/workshops
 * @access Admin only
 */
exports.createWorkshop = async (req, res) => {
  try {
    const data = { ...req.body };

    // 🧩 Required field check
    if (!data.city || !data.address) {
      return res.status(400).json({ message: "City and address are required" });
    }

    /* ============================================================
       🌍 Soft address validation — non-blocking (Promise.race)
       ============================================================ */
    const validateAddress = async () => {
      const validationUrl = `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(
        data.city
      )}&street=${encodeURIComponent(data.address)}&country=Israel&format=json`;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2500);

        const response = await fetch(validationUrl, {
          signal: controller.signal,
          headers: { "User-Agent": "Clalit-Workshops-App" },
        });
        clearTimeout(timeout);

        const validationData = await response.json();
        if (!Array.isArray(validationData) || validationData.length === 0) {
          console.warn(`⚠ Address not found in ${data.city} — saving anyway.`);
        }
      } catch (err) {
        console.warn(`⚠ Address validation skipped: ${err.message}`);
      }
    };

    // Fire without blocking save
    validateAddress().catch(() => {});

    /* ============================================================
       🧮 Days normalization
       ============================================================ */
    const daysMap = {
      ראשון: "Sunday",
      שני: "Monday",
      שלישי: "Tuesday",
      רביעי: "Wednesday",
      חמישי: "Thursday",
      שישי: "Friday",
      שבת: "Saturday",
    };

    if (!Array.isArray(data.days)) data.days = data.days ? [data.days] : [];
    data.days = data.days
      .map((d) => daysMap[d] || d)
      .filter((d) =>
        ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].includes(d)
      );

    if (data.days.length === 0) {
      return res.status(400).json({ message: "At least one valid day is required" });
    }

    /* ============================================================
       🗓 Validate core session info
       ============================================================ */
    if (!data.startDate) {
      return res.status(400).json({ message: "startDate is required" });
    }

    data.startDate = new Date(data.startDate);
    if (isNaN(data.startDate.getTime())) {
      return res.status(400).json({ message: "Invalid startDate" });
    }

    const count = parseInt(data.sessionsCount, 10);
    if (isNaN(count) || count < 1) {
      return res.status(400).json({ message: "sessionsCount must be a positive number" });
    }
    data.sessionsCount = count;

    /* ============================================================
       💤 Normalize inactive dates
       ============================================================ */
    if (!Array.isArray(data.inactiveDates)) {
      data.inactiveDates = data.inactiveDates ? [data.inactiveDates] : [];
    }
    data.inactiveDates = data.inactiveDates
      .map((d) => new Date(d))
      .filter((d) => !isNaN(d.getTime()));

    /* ============================================================
       💾 Save + auto endDate (triggered by schema pre('save'))
       ============================================================ */
    const ws = await Workshop.create(data);

    /* ============================================================
       📦 Normalize & respond
       ============================================================ */
    const normalized = {
      ...ws.toObject(),
      address: ws.address || "",
      city: ws.city || "",
      studio: ws.studio || "",
      coach: ws.coach || "",
    };

    const meta = {
      totalParticipants:
        (ws.participants?.length || 0) + (ws.familyRegistrations?.length || 0),
      waitingListCount: ws.waitingList?.length || 0,
      available: !!ws.available,
    };

    console.log("✅ Workshop created:", {
      title: ws.title,
      city: ws.city,
      days: ws.days,
      startDate: ws.startDate,
      endDate: ws.endDate,
    });

    return res.status(201).json({ success: true, data: normalized, meta });
  } catch (err) {
    console.error("❌ [createWorkshop] Error:", err);
    return res
      .status(500)
      .json({ message: err.message || "Failed to create workshop" });
  }
};


/* ------------------------------------------------------------
   🔴 DELETE /api/workshops/:id
------------------------------------------------------------ */
exports.deleteWorkshop = async (req, res) => {
  try {
    const ws = await Workshop.findByIdAndDelete(req.params.id);
    if (!ws) return res.status(404).json({ message: "Workshop not found" });
    res.json({ message: "Workshop deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting workshop:", err);
    res.status(400).json({ message: "Failed to delete workshop" });
  }
};

/* ------------------------------------------------------------
   🧩 GET /api/workshops/:id/participants
------------------------------------------------------------ */
// controllers/workshopController.js
exports.getWorkshopParticipants = async (req, res) => {
  try {
    const workshop = await Workshop.findById(req.params.id)
      .populate("participants", "name email phone city birthDate idNumber canCharge")
      .populate("familyRegistrations.parentUser", "name email phone city canCharge _id")
      .populate("familyRegistrations.familyMemberId", "name relation idNumber phone birthDate email city _id")
      .lean();

    if (!workshop) return res.status(404).json({ message: "Workshop not found" });

    // Normalize direct participants
    const participants = (workshop.participants || []).map((u) => ({
      _id: u._id,
      name: u.name,
      email: u.email || "",
      phone: u.phone || "",
      city: u.city || "",
      birthDate: u.birthDate || null,
      idNumber: u.idNumber || "",
      canCharge: !!u.canCharge,
      isFamily: false,
    }));

    // Normalize family registrations
    const familyRegistrations = (workshop.familyRegistrations || []).map((f) => {
  const parent = f.parentUser || {};
  return {
    _id: f.familyMemberId,
    familyMemberId: f.familyMemberId,
    parentId: parent._id || null,
    parentEmail: parent.email || "",
    parentPhone: parent.phone || "",
    name: f.name || "",
    relation: f.relation || "",
    email: f.email || parent.email || "",
    phone: f.phone || parent.phone || "",   // ✅ כאן יש את הפלאפון הנכון מה־DB
    city: f.city || parent.city || "",
    idNumber: f.idNumber || "",
    birthDate: f.birthDate || null,
    canCharge: !!parent.canCharge,
    isFamily: true,
  };
});


    // ✅ Return unified array (for UI simplicity)
    const all = [...participants, ...familyRegistrations];
    const participantsCount = all.length;

    return res.json({
      participants: all,
      participantsCount,
      directCount: participants.length,
      familyCount: familyRegistrations.length,
    });
  } catch (err) {
    console.error("❌ getWorkshopParticipants error:", err);
    res.status(500).json({ message: "Server error fetching participants" });
  }
};
/**
 * registerEntityToWorkshop
 * --------------------------------------------------------------------------
 * Registers either a user or one of their family members to a workshop.
 * - Adds to waiting list if full.
 * - Syncs User.userWorkshopMap / User.familyWorkshopMap.
 * - Uses shared services for consistency.
 */
exports.registerEntityToWorkshop = async (req, res) => {
  console.log("📩 [registerEntityToWorkshop] body:", req.body);
  console.log("👤 Auth user:", req.user?._id);

  try {
    const { familyId } = req.body;
    let workshop = await Workshop.findById(req.params.id);
    if (!workshop)
      return res.status(404).json({ message: "Workshop not found" });

    const isFamily = Boolean(familyId);
    const parentUser = await User.findById(req.user._id);
    if (!parentUser)
      return res.status(404).json({ message: "User not found" });

    let member = null;
    if (isFamily) {
      member = parentUser.familyMembers.id(familyId);
      if (!member) {
        console.warn("⚠️ Family member not found:", familyId);
        return res.status(404).json({ message: "Family member not found" });
      }
    }

    /* ============================================================
       🚫 Prevent duplicates
       ============================================================ */
    if (isFamily) {
      const alreadyRegistered = workshop.familyRegistrations.some(
        (r) =>
          String(r.familyMemberId) === String(familyId) &&
          String(r.parentUser) === String(req.user._id)
      );
      const alreadyQueued = (workshop.waitingList || []).some(
        (w) =>
          w.familyMemberId &&
          String(w.familyMemberId) === String(familyId) &&
          String(w.parentUser) === String(req.user._id)
      );
      if (alreadyRegistered)
        return res.status(400).json({ success: false, message: "Family member already registered" });
      if (alreadyQueued)
        return res.status(400).json({ success: false, message: "Family member already in waiting list" });
    } else {
      const alreadyUser = workshop.participants.some(
        (p) => String(p) === String(req.user._id)
      );
      const alreadyQueued = (workshop.waitingList || []).some(
        (w) =>
          !w.familyMemberId &&
          String(w.parentUser) === String(req.user._id)
      );
      if (alreadyUser)
        return res.status(400).json({ success: false, message: "User already registered" });
      if (alreadyQueued)
        return res.status(400).json({ success: false, message: "User already in waiting list" });
    }

    /* ============================================================
       📋 Capacity + waiting list
       ============================================================ */
    const hasSpace = workshop.canAddParticipant();
    if (!hasSpace) {
      if (
        workshop.waitingListMax > 0 &&
        workshop.waitingList.length >= workshop.waitingListMax
      ) {
        return res.status(400).json({
          success: false,
          message: "Workshop is full and waiting list is full",
        });
      }

      const entry = {
        parentUser: parentUser._id,
        familyMemberId: isFamily ? member._id : undefined,
        name: isFamily ? member.name : parentUser.name,
        relation: isFamily ? member.relation : "self",
        idNumber: isFamily ? member.idNumber : parentUser.idNumber,
        phone: isFamily ? member.phone : parentUser.phone,
        birthDate: isFamily ? member.birthDate : parentUser.birthDate,
      };
      workshop.waitingList.push(entry);
      await workshop.save();

      return res.json({
        success: true,
        message: "Added to waiting list",
        position: workshop.waitingList.length,
      });
    }

    /* ============================================================
       ✅ Normal registration
       ============================================================ */
    if (isFamily) {
      workshop.familyRegistrations.push({
        parentUser: parentUser._id,
        familyMemberId: member._id,
        name: member.name,
        relation: member.relation,
        idNumber: member.idNumber,
        phone: member.phone,
        birthDate: member.birthDate,
      });

      // update familyWorkshopMap
      const existing = parentUser.familyWorkshopMap.find(f =>
        String(f.familyMemberId) === String(member._id)
      );
      if (existing) {
        if (!existing.workshops.some(wid => String(wid) === String(workshop._id)))
          existing.workshops.push(workshop._id);
      } else {
        parentUser.familyWorkshopMap.push({
          familyMemberId: member._id,
          workshops: [workshop._id],
        });
      }
    } else {
      workshop.participants.push(req.user._id);
      if (!parentUser.userWorkshopMap.includes(workshop._id))
        parentUser.userWorkshopMap.push(workshop._id);
    }

    await workshop.save();
    await parentUser.save();

    /* ============================================================
       🎯 Return populated
       ============================================================ */
    const populated = await Workshop.findById(workshop._id)
      .populate("participants", "name email idNumber")
      .populate("familyRegistrations.parentUser", "name email idNumber")
      .populate("familyRegistrations.familyMemberId", "name relation idNumber phone birthDate")
      .populate("waitingList.parentUser", "name email");

    res.json({ success: true, workshop: populated });
  } catch (err) {
    console.error("🔥 registerEntityToWorkshop error:", err);
    res.status(500).json({ message: "Server error during registration", error: err.message });
  }
};


/**
 * unregisterEntityFromWorkshop
 * --------------------------------------------------------------------------
 * Removes either a user or a family member from a workshop.
 * Keeps Workshop and User mappings in sync.
 */
exports.unregisterEntityFromWorkshop = async (req, res) => {
  try {
    const { id } = req.params; // workshopId
    const { familyId, userId: overrideUserId, parentUserId } = req.body;
    const isAdmin = req.user?.role === "admin";

    const actingUserId  = isAdmin && overrideUserId ? overrideUserId : req.user._id;
    const actingParentId = isAdmin && parentUserId ? parentUserId : req.user._id;

    const parentUser = await User.findById(actingParentId);
    if (!parentUser) return res.status(404).json({ message: "User not found" });

    const workshop = await Workshop.findById(id);
    if (!workshop) return res.status(404).json({ message: "Workshop not found" });

    let changed = false;
    if (familyId) {
      const before = workshop.familyRegistrations.length;
      workshop.familyRegistrations = workshop.familyRegistrations.filter(f =>
        !(String(f.familyMemberId) === String(familyId) && String(f.parentUser) === String(actingParentId))
      );
      changed = before !== workshop.familyRegistrations.length;

      // sync familyWorkshopMap
      const mapEntry = parentUser.familyWorkshopMap.find(f =>
        String(f.familyMemberId) === String(familyId)
      );
      if (mapEntry) {
        mapEntry.workshops = mapEntry.workshops.filter(wid => String(wid) !== String(id));
      }
    } else {
      const before = workshop.participants.length;
      workshop.participants = workshop.participants.filter(u => String(u) !== String(actingUserId));
      changed = before !== workshop.participants.length;

      // sync userWorkshopMap
      parentUser.userWorkshopMap = parentUser.userWorkshopMap.filter(wid => String(wid) !== String(id));
    }

    if (changed) {
      workshop.participantsCount =
        (workshop.participants?.length || 0) + (workshop.familyRegistrations?.length || 0);
      await workshop.save();
      await parentUser.save();
    }

    return res.json({ success: true, changed, message: "Entity unregistered successfully" });
  } catch (err) {
    console.error("❌ unregisterEntityFromWorkshop error:", err);
    res.status(500).json({ success: false, message: "Server error during unregistration" });
  }
};







/**
 * ============================================================
 * WAITLIST REGISTRATION HANDLERS (User + Family)
 * ============================================================
 */

/**
 * POST /api/workshops/:id/waitlist-entity
 * Adds a user or family member to the waiting list.
 */
exports.addEntityToWaitlist = async (req, res) => {
  try {
    const { id } = req.params;
    const { familyId } = req.body;
    const user = req.user;

    const workshop = await Workshop.findById(id);
    if (!workshop)
      return res.status(404).json({ success: false, message: "Workshop not found" });

    // ✅ בדיקה אם כבר ברשימת ההמתנה
    const already = (workshop.waitingList || []).some(
      (e) =>
        e.parentUser.toString() === user._id.toString() &&
        (familyId
          ? e.familyMemberId?.toString() === familyId.toString()
          : !e.familyMemberId)
    );
    if (already)
      return res
        .status(400)
        .json({ success: false, message: "Already in waiting list" });

    // ✅ בדיקה אם יש מקום ברשימת ההמתנה
    if (
      workshop.waitingListMax > 0 &&
      workshop.waitingList.length >= workshop.waitingListMax
    ) {
      return res.status(400).json({
        success: false,
        message: "Waiting list is full",
      });
    }

    // ✅ בניית הרשומה החדשה
    const member = familyId
      ? user.familyMembers?.id(familyId)
      : null;

    const entry = {
      parentUser: user._id,
      familyMemberId: familyId || undefined,
      name: member ? member.name : user.name,
      relation: member ? member.relation : "self",
      idNumber: member ? member.idNumber : user.idNumber,
      phone: member ? member.phone : user.phone,
      birthDate: member ? member.birthDate : user.birthDate,
    };

    workshop.waitingList.push(entry);
    await workshop.save();

    res.json({
      success: true,
      message: "Added to waiting list successfully",
      position: workshop.waitingList.length,
    });
  } catch (err) {
    console.error("🔥 addEntityToWaitlist error:", err);
    res.status(500).json({
      success: false,
      message: "Server error adding to waitlist",
    });
  }
};

/**
 * DELETE /api/workshops/:id/waitlist-entity
 * Removes a user or family member from the waiting list.
 */
exports.removeEntityFromWaitlist = async (req, res) => {
  try {
    const { id } = req.params;
    const { familyId } = req.body;
    const user = req.user;

    const workshop = await Workshop.findById(id);
    if (!workshop)
      return res
        .status(404)
        .json({ success: false, message: "Workshop not found" });

    const before = workshop.waitingList.length;
    workshop.waitingList = (workshop.waitingList || []).filter((e) => {
      const isParent = e.parentUser.toString() === user._id.toString();
      const isFamilyMatch = familyId
        ? e.familyMemberId?.toString() === familyId.toString()
        : !e.familyMemberId;
      return !(isParent && isFamilyMatch);
    });

    if (before === workshop.waitingList.length) {
      return res.status(404).json({
        success: false,
        message: "Entry not found in waiting list",
      });
    }

    await workshop.save();
    res.json({
      success: true,
      message: "Removed from waiting list successfully",
    });
  } catch (err) {
    console.error("🔥 removeEntityFromWaitlist error:", err);
    res.status(500).json({
      success: false,
      message: "Server error removing from waitlist",
    });
  }
};

/* ------------------------------------------------------------
   📊 POST /api/workshops/:id/export — Admin only
   מייצר קובץ אקסל עם רשימת המשתתפים ושולח למייל של המנהל
------------------------------------------------------------ */

/**
 * Export full workshop participants (and waiting list) to Excel
 * Admin-only access
 */
exports.exportWorkshopExcel = async (req, res) => {
  try {
    const admin = req.user;
    if (!admin || admin.role !== "admin") {
      return res.status(403).json({ message: "Access denied" });
    }

    const workshopId = req.params.id;

    // 🧩 Utilities
    const pad = (n) => String(n).padStart(2, "0");
    const toHebDate = (d) => {
      if (!d) return "";
      const dt = new Date(d);
      if (isNaN(dt)) return "";
      return `${pad(dt.getDate())}.${pad(dt.getMonth() + 1)}.${dt.getFullYear()}`;
    };
    const calcAge = (dob) => {
      if (!dob) return "";
      const d = new Date(dob);
      if (isNaN(d)) return "";
      const now = new Date();
      let a = now.getFullYear() - d.getFullYear();
      const m = now.getMonth() - d.getMonth();
      if (m < 0 || (m === 0 && now.getDate() < d.getDate())) a--;
      return a;
    };

    // 🧩 Fetch workshop
    const workshop = await Workshop.findById(workshopId)
      .populate("participants", "name email phone city birthDate idNumber canCharge")
      .populate("familyRegistrations.parentUser", "name email phone city canCharge")
      .populate("familyRegistrations.familyMemberId", "name relation idNumber phone birthDate")
      .populate("waitingList.parentUser", "name email phone city canCharge")
      .lean();

    if (!workshop) return res.status(404).json({ message: "Workshop not found" });

    // 🧩 Handle default values
    const startDate = workshop.startDate ? new Date(workshop.startDate) : new Date(workshop.createdAt);
    const periodDays = Number(workshop.timePeriod) || 30;
    const endDate = new Date(startDate.getTime() + periodDays * 24 * 60 * 60 * 1000);

    const startDateStr = toHebDate(startDate);
    const endDateStr = toHebDate(endDate);

    // 🧾 Determine which sections to include based on query param
    const exportType = String(req.query.type || "").toLowerCase();
    const includeParticipants = !exportType || exportType === "current";
    const includeWaitlist = !exportType || exportType === "waitlist";

    // 🧾 Create Excel file (participants and/or waitlist)
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('דו"ח משתתפים', { views: [{ rightToLeft: true }] });

    sheet.columns = [
      { header: "שם משתתף", key: "p_name", width: 25 },
      { header: "קרבה", key: "p_relation", width: 15 },
      { header: "אימייל", key: "p_email", width: 25 },
      { header: "טלפון", key: "p_phone", width: 16 },
      { header: "תעודת זהות", key: "p_id", width: 16 },
      { header: "תאריך לידה", key: "p_birth", width: 15 },
      { header: "גיל", key: "p_age", width: 8 },
      { header: "ניתן לגבות", key: "p_cancharge", width: 12 },
      { header: "מקור", key: "origin", width: 16 },
    ];

    const header = sheet.getRow(1);
    header.font = { bold: true };
    header.alignment = { horizontal: "center" };

    // ✅ Participants (main users)
    if (includeParticipants) {
      (workshop.participants || []).forEach((p) => {
        sheet.addRow({
          p_name: p.name || "",
          p_relation: "עצמי",
          p_email: p.email || "",
          p_phone: p.phone || "",
          p_id: p.idNumber || "",
          p_birth: toHebDate(p.birthDate),
          p_age: calcAge(p.birthDate),
          p_cancharge: p.canCharge ? "כן" : "לא",
          origin: "משתתף",
        });
      });

      // ✅ Family members (participants)
      (workshop.familyRegistrations || []).forEach((fr) => {
        const fm = fr.familyMemberId || {};
        const parent = fr.parentUser || {};
        const email = fm.email || parent.email || "";
        const phone = fm.phone || parent.phone || "";
        const canCharge = parent.canCharge ? "כן" : "לא";
        sheet.addRow({
          p_name: fm.name || fr.name || "",
          p_relation: fm.relation || fr.relation || "בן משפחה",
          p_email: email,
          p_phone: phone,
          p_id: fm.idNumber || fr.idNumber || "",
          p_birth: toHebDate(fm.birthDate || fr.birthDate),
          p_age: calcAge(fm.birthDate || fr.birthDate),
          p_cancharge: canCharge,
          origin: "משתתף",
        });
      });
    }

    // 🔹 Add separator if both participants and waitlist are included
    if (includeParticipants && includeWaitlist) {
      const sepRowIdx = sheet.lastRow.number + 2;
      sheet.mergeCells(sepRowIdx, 1, sepRowIdx, sheet.columnCount);
      const sep = sheet.getCell(sepRowIdx, 1);
      sep.value = "— רשימת המתנה —";
      sep.alignment = { horizontal: "center" };
      sheet.getRow(sepRowIdx).font = { bold: true };
    }

    // ✅ Waiting list
    if (includeWaitlist) {
      (workshop.waitingList || []).forEach((wl) => {
        const parent = wl.parentUser || {};
        const email = wl.email || parent.email || "";
        const phone = wl.phone || parent.phone || "";
        const canCharge = parent.canCharge ? "כן" : "לא";
        sheet.addRow({
          p_name: wl.name || "",
          p_relation: wl.relation || (wl.familyMemberId ? "בן משפחה" : "עצמי"),
          p_email: email,
          p_phone: phone,
          p_id: wl.idNumber || "",
          p_birth: toHebDate(wl.birthDate),
          p_age: calcAge(wl.birthDate),
          p_cancharge: canCharge,
          origin: "רשימת המתנה",
        });
      });
    }

    const buffer = await workbook.xlsx.writeBuffer();

    // 🧩 Build RTL Hebrew email body
    const maxCap = Number(workshop.maxParticipants ?? 0);
    const capStr = maxCap === 0 ? "∞" : String(maxCap);

    const statsLine = `${(workshop.participantsCount ??
      (workshop.participants?.length || 0) +
      (workshop.familyRegistrations?.length || 0))} מתוך ${capStr}`;

    const waitCount = workshop.waitingList?.length || 0;

    // ✅ Use `days` array (schema) instead of non-existent `day`
    const hebLetters = {
      Sunday: "א",
      Monday: "ב",
      Tuesday: "ג",
      Wednesday: "ד",
      Thursday: "ה",
      Friday: "ו",
      Saturday: "ש",
    };
    const daysStr = Array.isArray(workshop.days) && workshop.days.length
      ? workshop.days.map((d) => hebLetters[d] || d).join(", ")
      : "-";
    const hourStr = workshop.hour || "-";

    const plainBody = `
שלום ${admin.name},

להלן דו״ח הסדנה "${workshop.title || "-"}":

פרטי הסדנה:
• סוג: ${workshop.type || "-"}
• מאמן: ${workshop.coach || "-"}
• סטודיו: ${workshop.studio || "-"}
• עיר: ${workshop.city || "-"}
• ימים: ${daysStr}
• שעה: ${hourStr}
• תאריך התחלה: ${startDateStr}
• תאריך סיום: ${endDateStr}
• תקופה (ימים): ${periodDays}
• כמות משתתפים: ${statsLine}
• רשימת המתנה: ${waitCount} משתתפים

מצורף קובץ אקסל עם רשימת המשתתפים ורשימת ההמתנה.

בברכה,
מערכת הסדנאות
`;

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    });

    await transporter.sendMail({
      from: `"מערכת סדנאות" <${process.env.EMAIL_USER}>`,
      to: admin.email,
      subject: `📊 דו״ח סדנה — ${workshop.title || ""}`,
      text: plainBody,
      html: `
    <div dir="rtl" style="font-family: 'Segoe UI', sans-serif; text-align: right; line-height: 1.6; color: #222; font-size: 15px;">
      <p>שלום ${admin.name},</p>
      <p>להלן דו״ח הסדנה <strong>"${workshop.title || "-"}"</strong>:</p>

      <h3 style="margin-bottom: 8px; margin-top: 16px;">פרטי הסדנה:</h3>
      <ul style="list-style-type: none; padding: 0; margin: 0;">
        <li>• סוג: ${workshop.type || "-"}</li>
        <li>• מאמן: ${workshop.coach || "-"}</li>
        <li>• סטודיו: ${workshop.studio || "-"}</li>
        <li>• עיר: ${workshop.city || "-"}</li>
        <li>• ימים: ${daysStr}</li>
        <li>• שעה: ${hourStr}</li>
        <li>• תאריך התחלה: ${startDateStr}</li>
        <li>• תאריך סיום: ${endDateStr}</li>
        <li>• תקופה (ימים): ${periodDays}</li>
        <li>• כמות משתתפים: ${statsLine}</li>
        <li>• רשימת המתנה: ${waitCount} משתתפים</li>
      </ul>

      <p style="margin-top: 16px;">
        מצורף קובץ אקסל עם רשימת המשתתפים ורשימת ההמתנה.
      </p>

      <p style="margin-top: 24px;">
        בברכה,<br/>
        <strong>מערכת הסדנאות</strong>
      </p>
    </div>
  `,
      attachments: [
        {
          filename: `דו״ח משתתפים - ${workshop.title || "ללא שם"}.xlsx`,
          content: buffer,
          contentType:
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        },
      ],
    });

    res.json({ success: true, message: "Excel sent successfully" });
  } catch (err) {
    console.error("❌ exportWorkshopExcel error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};


/* ------------------------------------------------------------
   📝 GET /api/workshops/:id/waitlist — Admin only
   Returns the current waiting list for a workshop.  Useful for
   reviewing queue order and manually promoting or removing
   entries.
------------------------------------------------------------ */
exports.getWaitlist = async (req, res) => {
  try {
    const { id } = req.params;
    const workshop = await Workshop.findById(id).populate("waitingList.parentUser", "name email");
    if (!workshop) return res.status(404).json({ message: "Workshop not found" });
    return res.json(workshop.waitingList || []);
  } catch (err) {
    console.error("❌ getWaitlist error:", err);
    res.status(500).json({ message: "Server error fetching waitlist" });
  }
};

/* ------------------------------------------------------------
   ➕ POST /api/workshops/:id/waitlist — Admin only
   Allows an admin to manually add a user or family member to
   the waiting list.  Accepts { userId, familyId } in body.
------------------------------------------------------------ */
exports.addToWaitlist = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId, familyId } = req.body;
    const workshop = await Workshop.findById(id);
    if (!workshop) return res.status(404).json({ message: "Workshop not found" });
    // Ensure waiting list has space
    if (workshop.waitingListMax > 0 && workshop.waitingList.length >= workshop.waitingListMax) {
      return res.status(400).json({ message: "Waiting list at capacity" });
    }
    // Lookup parent user
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });
    let member = null;
    if (familyId) {
      member = user.familyMembers.id(familyId);
      if (!member) return res.status(404).json({ message: "Family member not found" });
    }
    // Prevent duplicates
    const duplicate = (workshop.waitingList || []).some((e) => {
      if (familyId) {
        return e.familyMemberId && e.familyMemberId.toString() === familyId.toString() && e.parentUser.toString() === userId.toString();
      }
      return !e.familyMemberId && e.parentUser.toString() === userId.toString();
    });
    if (duplicate) return res.status(400).json({ message: "Already on waiting list" });
    // Build entry
    const entry = {
      parentUser: user._id,
      familyMemberId: familyId || undefined,
      name: familyId ? member.name : user.name,
      relation: familyId ? member.relation : "self",
      idNumber: familyId ? member.idNumber : user.idNumber,
      phone: familyId ? member.phone : user.phone,
      birthDate: familyId ? member.birthDate : user.birthDate,
    };
    workshop.waitingList.push(entry);
    await workshop.save();
    return res.json({ success: true, message: "Added to waiting list", waitlist: workshop.waitingList });
  } catch (err) {
    console.error("❌ addToWaitlist error:", err);
    res.status(500).json({ message: "Server error adding to waitlist" });
  }
};

/* ------------------------------------------------------------
   ➖ DELETE /api/workshops/:id/waitlist/:entryId — Admin only
   Removes an entry from the waiting list by its subdocument id.
------------------------------------------------------------ */
exports.removeFromWaitlist = async (req, res) => {
  try {
    const { id, entryId } = req.params;
    const workshop = await Workshop.findById(id);
    if (!workshop) return res.status(404).json({ message: "Workshop not found" });
    const before = workshop.waitingList.length;
    workshop.waitingList = (workshop.waitingList || []).filter((e) => e._id.toString() !== entryId.toString());
    if (workshop.waitingList.length === before) return res.status(404).json({ message: "Waitlist entry not found" });
    await workshop.save();
    return res.json({ success: true, message: "Removed from waiting list", waitlist: workshop.waitingList });
  } catch (err) {
    console.error("❌ removeFromWaitlist error:", err);
    res.status(500).json({ message: "Server error removing from waitlist" });
  }
};
// ✅ מחזיר רשימת ערים בישראל ממקור ממשלתי (או fallback ל-local)
exports.getAvailableCities = async (req, res) => {
  try {
    // ✅ ניסיון ראשון – קריאה ל-API ממשלתי
    const url =
      "https://data.gov.il/api/3/action/datastore_search?resource_id=bb040a11-b8b0-46a9-bc48-63a972df2a5b&limit=5000";
    const response = await fetch(url, {
      headers: { "User-Agent": "Clalit-Workshops-App" },
    });

    const data = await response.json();

    const cities =
      data?.result?.records
        ?.map((r) => r["שם_ישוב"] || r["שם_ישוב_לועזי"])
        ?.filter(Boolean) || [];

    if (!cities.length) throw new Error("No cities found from data.gov.il");

    const unique = [...new Set(cities)].sort();
    console.log(`✅ Loaded ${unique.length} cities from data.gov.il`);
    return res
      .status(200)
      .json({ success: true, source: "data.gov.il", count: unique.length, cities: unique });
  } catch (err) {
    console.warn("⚠️ Failed to fetch cities:", err.message);

    // ✅ fallback מיוחד לאזור הנגב והדרום
    const southernCities = [
      "באר שבע",
      "כרמים",
      "כרמית",
      "דימונה",
      "ערד",
      "ירוחם",
      "אופקים",
      "שדרות",
      "נתיבות",
      "רהט",
      "להבים",
      "מיתר",
      "עומר",
      "חורה",
      "תל שבע",
      "כסייפה",
      "ערערה בנגב",
      "שגב שלום",
      "מרחבים",
      "בני שמעון",
      "אשכול",
      "חוף אשקלון",
      "מצפה רמון",
      "אילת",
      "צאלים",
      "שדה בוקר",
      "חצרים",
      "משאבי שדה",
      "קדש ברנע",
      "עין יהב",
      "ספיר",
    ];

    return res.status(200).json({
      success: true,
      source: "fallback-southern",
      count: southernCities.length,
      cities: southernCities,
    });
  }
};

// ✅ בודק אם הכתובת שייכת לעיר בעזרת OpenStreetMap (Nominatim)
exports.validateAddress = async (req, res) => {
  const { city, address } = req.query;
  if (!city || !address)
    return res.status(400).json({ success: false, message: "city and address are required" });

  try {
    const url = `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(
      city
    )}&street=${encodeURIComponent(address)}&country=Israel&format=json`;
    const response = await fetch(url, { headers: { "User-Agent": "Clalit-Workshops-App" } });
    const data = await response.json();

    const valid = Array.isArray(data) && data.length > 0;
    res.status(200).json({
      success: true,
      valid,
      message: valid ? "Address matches city" : "Address not found for this city",
    });
  } catch (err) {
    console.error("❌ Address validation error:", err.message);
    res.status(500).json({ success: false, message: "Validation service unavailable" });
  }
};

/* ============================================================
   🔍 searchWorkshops — Atlas Compound Search + Fallback
   Mirrors searchUsers for consistent UX & query logic
   ============================================================ */
exports.searchWorkshops = async (req, res) => {
  try {
    // Normalize query
    const raw = (req.query.q || "").trim();
    if (!raw) return res.json([]);
// was: const q = normalizeSearchQuery(raw);
    const q = normalizeWorkshopQuery(raw);
    const escaped = escapeRegex(q);
    const wildcardToken = `*${q}*`;
    const limit = Math.max(1, Math.min(parseInt(req.query.limit || "60", 10) || 60, 200));

    // Filters
    const cityFilter = req.query.city;
    const typeFilter = req.query.type;
    const coachFilter = req.query.coach;
    const dayFilter = req.query.day;
    const hourFilter = req.query.hour;
    const availableParam = req.query.available;
    const ageGroupFilter = req.query.ageGroup;
    const availableFilter =
      availableParam !== undefined
        ? String(availableParam).toLowerCase() === "true"
        : undefined;

    // Clean filter object
    const filterObj = {};
    if (cityFilter) filterObj.city = { $regex: new RegExp(escapeRegex(cityFilter), "i") };
    if (typeFilter) filterObj.type = typeFilter;
    if (coachFilter) filterObj.coach = { $regex: new RegExp(escapeRegex(coachFilter), "i") };
    if (hourFilter) filterObj.hour = { $regex: new RegExp(escapeRegex(hourFilter), "i") };
    if (dayFilter) filterObj.days = dayFilter;
    if (ageGroupFilter) filterObj.ageGroup = ageGroupFilter;
    if (availableFilter !== undefined) filterObj.available = availableFilter;

    // Projection
    const projection = {
      title: 1,
      coach: 1,
      type: 1,
      city: 1,
      days: 1,
      hour: 1,
      ageGroup: 1,
      available: 1,
      image: 1,
      price: 1,
      participantsCount: 1,
      maxParticipants: 1,
      startDate: 1,
      endDate: 1,
    };

    // ----------------------------
    // Atlas Compound Search
    // ----------------------------
    const SEARCH_ANALYZED = ["title", "description", "coach", "city", "type", "studio"];
    const SEARCH_KEYWORD = [
      "title_keyword",
      "description_keyword",
      "coach_keyword",
      "city_keyword",
      "type_keyword",
      "studio_keyword",
    ];

    const pipeline = [
      {
        $search: {
          index: "WorkshopTextIndex",
          compound: {
            should: [
              { text: { query: q, path: SEARCH_ANALYZED } },
              { wildcard: { path: SEARCH_KEYWORD, query: wildcardToken, allowAnalyzedField: true } },
              { text: { query: q, path: SEARCH_ANALYZED, fuzzy: { maxEdits: 1 } } },
              { regex: { path: SEARCH_KEYWORD, query: escaped, allowAnalyzedField: true } },
            ],
            minimumShouldMatch: 1,
          },
        },
      },
      { $match: filterObj },
      { $limit: Math.max(limit * 2, 60) },
      {
        $project: {
          ...projection,
          score: { $meta: "searchScore" },
          highlights: { $meta: "searchHighlights" },
        },
      },
    ];

    let docs = [];
    let clauseUsed = "Atlas compound";
    const start = Date.now();

    try {
      docs = await Workshop.aggregate(pipeline);
    } catch (err) {
      console.error("⚠️ Atlas $search error:", err.message);
      clauseUsed = "Atlas error → fallback regex";
      docs = [];
    }

    // ----------------------------
    // Fallback if Atlas failed or empty
    // ----------------------------
    if (!docs.length) {
      console.log("⚙️ [fallback] Running regex fallback for:", q);
      const rx = new RegExp(escapeRegex(q), "i");
      docs = await Workshop.find({
        $or: [
          { title: rx },
          { description: rx },
          { coach: rx },
          { type: rx },
          { city: rx },
          { studio: rx },
        ],
        ...filterObj,
      })
        .select(projection)
        .limit(limit)
        .lean();
      clauseUsed = "fallback regex";
    }

    // ----------------------------
    // Final filtering
    // ----------------------------
    const filtered = docs.filter((w) => {
      if (dayFilter) {
        const days = Array.isArray(w.days) ? w.days : [];
        if (!days.includes(dayFilter)) return false;
      }
      return true;
    });

    const took = Date.now() - start;
    console.groupCollapsed(`🧩 [searchWorkshops] (${clauseUsed}, ${took} ms)`);
    console.log("Query:", q, "| Docs:", filtered.length);
    if (filtered[0]) {
      console.log("Sample:", {
        _id: filtered[0]._id,
        title: filtered[0].title,
        coach: filtered[0].coach,
        city: filtered[0].city,
        score: filtered[0].score,
      });
    }
    console.groupEnd();

    return res.json(filtered.slice(0, limit));
  } catch (err) {
    console.error("❌ [searchWorkshops] Error:", err);
    res.status(500).json({
      message: "Server error performing workshop search",
      error: err.message,
    });
  }
};

