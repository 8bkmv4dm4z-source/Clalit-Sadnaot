/**
 * cleanup.js — Artillery Pre-Test Processor (Fixed)
 * -------------------------------------------------
 * Deletes old test users before main scenario runs.
 * Uses async/await + native fetch (no k6 dependency, no done()).
 */

export async function cleanupUsers(context, events) {
  const emails = Array.from({ length: 20 }, (_, i) => `u${i + 1}@test.com`);
  const base = "http://localhost:5000";

  console.log("🧹 Starting cleanup of old test users...");

  let deleted = 0;

  for (const email of emails) {
    try {
      const res = await fetch(`${base}/api/dev/cleanup-user`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      if (res.status === 200) {
        deleted++;
        console.log(`✅ Deleted ${email}`);
      } else if (res.status === 404) {
        console.log(`⚠️ Not found (already clean): ${email}`);
      } else {
        console.warn(`❌ Failed ${email}: ${res.status}`);
      }
    } catch (err) {
      console.error(`🔥 Error deleting ${email}:`, err.message);
    }
  }

  console.log(`✅ Cleanup complete: ${deleted}/${emails.length} users deleted.`);
}
