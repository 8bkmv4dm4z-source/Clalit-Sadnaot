export { default } from './MyWorkshops';
