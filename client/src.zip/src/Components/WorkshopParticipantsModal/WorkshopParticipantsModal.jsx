// src/Components/WorkshopParticipantsModal.jsx
import React, { useEffect, useState, useCallback } from "react";
import { useWorkshops } from "../../layouts/WorkshopContext";
import { useAuth } from "../../layouts/AuthLayout";

const calcAge = (dateStr) => {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d)) return null;
  const t = new Date();
  let a = t.getFullYear() - d.getFullYear();
  const m = t.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && t.getDate() < d.getDate())) a--;
  return a;
};

/**
 * WorkshopParticipantsModal.jsx — Canonical Save + Live Refresh
 * -------------------------------------------------------------
 * ✅ Edits (user/family) go through Auth.saveEntity(...)
 * ✅ After any change: refreshMe() → fetchAll() → fetchWorkshops()
 * ✅ Family email falls back to parent email for display
 */
export default function WorkshopParticipantsModal({ workshop, onClose }) {
  const {
    registerEntityToWorkshop,
    unregisterEntityFromWorkshop,
    fetchWorkshops,
  } = useWorkshops();
  const { saveEntity, refreshMe } = useAuth();

  const [participants, setParticipants] = useState([]);
  const [familyMembers, setFamilyMembers] = useState([]);
  const [selectedFamilyId, setSelectedFamilyId] = useState("");
  const [editingUserId, setEditingUserId] = useState(null);
  const [editingIsFamily, setEditingIsFamily] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const [fetchCooldown, setFetchCooldown] = useState(false);

  const safeFetchWorkshops = async () => {
    if (fetchCooldown) return;
    setFetchCooldown(true);
    await fetchWorkshops();
    setTimeout(() => setFetchCooldown(false), 1500);
  };

  const fetchAll = useCallback(async () => {
    if (!workshop?._id) return;
    setLoading(true);
    setMessage(null);
    try {
      const token = localStorage.getItem("token");

      const [participantsRes, familyRes] = await Promise.all([
        fetch(`/api/workshops/${workshop._id}/participants`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`/api/users/me`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      const [participantsData, familyData] = await Promise.all([
        participantsRes.json(),
        familyRes.json(),
      ]);

      if (!participantsRes.ok)
        throw new Error(participantsData.message || "שגיאה בטעינת משתתפים");
      if (!familyRes.ok)
        throw new Error(familyData.message || "שגיאה בטעינת בני משפחה");

      const merged = [
        ...(participantsData.participants || []), // users
        ...(participantsData.familyRegistrations || []).map((f) => ({
          ...f,
          isFamily: true,
          _id: f._id ?? f.familyMemberId,
          parentEmail: f.parentEmail, // if backend returns
        })),
      ];

      setParticipants(merged);
      setFamilyMembers(familyData.familyMembers || []);
    } catch (err) {
      console.error("❌ [Modal] Fetch error:", err);
      setMessage(`❌ ${err.message}`);
    } finally {
      setLoading(false);
    }
  }, [workshop?._id]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const handleEditToggle = (row) => {
    if (editingUserId === row._id) {
      setEditingUserId(null);
      setEditingIsFamily(false);
      setEditForm({});
    } else {
      setEditingUserId(row._id);
      setEditingIsFamily(!!row.isFamily);
      setEditForm({ ...row });
    }
  };

  useEffect(() => {
    if (!editingUserId) return;
    let aborted = false;
    (async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(`/api/users/entity/${editingUserId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "שגיאה בטעינת פרטי משתמש/בן משפחה");

        if (!aborted) {
          setEditingIsFamily(data.type === "familyMember");
          setEditForm(data.entity || {});
        }
      } catch (err) {
        console.error("❌ Failed to fetch entity:", err);
        setMessage(`❌ ${err.message}`);
      }
    })();
    return () => {
      aborted = true;
    };
  }, [editingUserId]);

  const handleChange = (key, value) => {
    setEditForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveUser = async () => {
    if (!editingUserId) return;

    try {
      setSaving(true);
      const payload = editingIsFamily
        ? {
            familyId: editingUserId,
            updates: {
              ...editForm,
              email: editForm.email || editForm.parentEmail || "", // ✅ fallback
            },
          }
        : { userId: editingUserId, updates: editForm };

      const res = await saveEntity(payload);
      if (!res.success) throw new Error(res.message || "שגיאה בעדכון");

      setMessage("✅ עודכן בהצלחה");
      setEditingUserId(null);
      setEditingIsFamily(false);
      setEditForm({});
      await refreshMe();
      await fetchAll();
      await safeFetchWorkshops();
    } catch (err) {
      console.error("❌ handleSaveUser error:", err);
      setMessage(`❌ ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleAddFamily = async () => {
    if (!selectedFamilyId) return setMessage("⚠️ בחר בן משפחה להוספה");
    try {
      const result = await registerEntityToWorkshop(workshop._id, selectedFamilyId);
      if (result.success) {
        setMessage("✅ בן המשפחה נרשם בהצלחה!");
        setSelectedFamilyId("");
        await refreshMe();
        await fetchAll();
        await safeFetchWorkshops();
      } else {
        setMessage(result.message || "❌ שגיאה בהרשמת בן משפחה");
      }
    } catch (err) {
      console.error("❌ handleAddFamily error:", err);
      setMessage("❌ שגיאה בהרשמת בן משפחה");
    }
  };

  const handleRemoveFamily = async (familyId) => {
    try {
      const result = await unregisterEntityFromWorkshop(workshop._id, familyId);
      if (result.success) {
        setMessage("🚫 בן המשפחה הוסר בהצלחה");
        await refreshMe();
        await fetchAll();
        await safeFetchWorkshops();
      } else {
        setMessage(result.message || "❌ שגיאה בהסרת בן משפחה");
      }
    } catch (err) {
      console.error("❌ handleRemoveFamily error:", err);
      setMessage("❌ שגיאה בהסרת בן משפחה");
    }
  };

  const renderEditForm = (p) => (
    <div key={p._id} className="border border-gray-200 rounded-xl p-4 bg-gray-50 shadow-sm">
      <h4 className="text-lg font-semibold text-gray-800 mb-2">עריכת {p.name}</h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {["name", "email", "city", "phone"].map((field) => (
          <input
            key={field}
            className="border rounded-lg px-2 py-1 text-sm"
            value={editForm[field] || ""}
            onChange={(e) => handleChange(field, e.target.value)}
            placeholder={field}
          />
        ))}
        <input
          type="date"
          className="border rounded-lg px-2 py-1 text-sm"
          value={editForm.birthDate?.split("T")[0] || ""}
          onChange={(e) => handleChange("birthDate", e.target.value)}
        />
        <input
          className="border rounded-lg px-2 py-1 text-sm"
          value={editForm.idNumber || ""}
          onChange={(e) => handleChange("idNumber", e.target.value)}
          placeholder="idNumber"
        />
        {!p.isFamily && (
          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input
              type="checkbox"
              checked={!!editForm.canCharge}
              onChange={(e) => handleChange("canCharge", e.target.checked)}
              className="w-4 h-4 accent-indigo-500"
            />
            הרשאה לגבייה
          </label>
        )}
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <button
          onClick={() => handleEditToggle(p)}
          className="px-4 py-1.5 rounded-lg text-sm border border-gray-300 text-gray-700 hover:bg-gray-100"
        >
          ביטול
        </button>
        <button
          onClick={handleSaveUser}
          className="px-4 py-1.5 rounded-lg text-sm bg-green-600 text-white hover:bg-green-700"
        >
          {saving ? "שומר..." : "שמור"}
        </button>
      </div>
    </div>
  );

  const renderParticipant = (p) => {
    const email = p.email || p.parentEmail || "-"; // ✅ fallback
    const age = calcAge(p.birthDate);
    return (
      <div
        key={p._id}
        className="border border-gray-200 rounded-xl p-4 bg-white shadow-sm hover:shadow-md transition"
      >
        <h4 className="text-lg font-semibold text-gray-800">
          {p.name}{" "}
          {p.isFamily && (
            <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
              בן משפחה
            </span>
          )}
        </h4>
        <p className="text-sm text-gray-600">{email}</p>
        <div className="text-xs text-gray-500 mt-1 space-y-0.5">
          <p>טלפון: {p.phone || "-"}</p>
          <p>עיר: {p.city || "-"}</p>
          <p>
            תאריך לידה: {p.birthDate ? new Date(p.birthDate).toLocaleDateString("he-IL") : "-"}
            {typeof age === "number" && <> — גיל: {age}</>}
          </p>
          <p>ת.ז: {p.idNumber || "-"}</p>
          {!p.isFamily && (
            <p>
              גבייה:{" "}
              <span className={`font-bold ${p.canCharge ? "text-green-600" : "text-red-500"}`}>
                {p.canCharge ? "✅ כן" : "🚫 לא"}
              </span>
            </p>
          )}
        </div>
        <div className="flex justify-between items-center mt-3">
          <button
            onClick={() => handleEditToggle(p)}
            className="px-3 py-1.5 text-sm rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
          >
            ערוך
          </button>
          {p.isFamily ? (
            <button
              onClick={() => handleRemoveFamily(p._id)}
              className="text-red-600 hover:underline text-xs"
            >
              הסר בן משפחה
            </button>
          ) : (
            <button
              onClick={() => unregisterEntityFromWorkshop(workshop._id)}
              className="text-red-600 hover:underline text-xs"
            >
              בטל הרשמה
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="w-full max-w-4xl rounded-2xl bg-white shadow-2xl p-6 animate-[fadeIn_.15s_ease]"
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-xl font-bold text-gray-800">
            משתתפים בסדנה: <span className="text-indigo-600">{workshop.title}</span>
          </h3>
          <button onClick={onClose} className="rounded-lg px-3 py-1 text-sm text-gray-600 hover:bg-gray-100">
            ✕ סגור
          </button>
        </div>

        {familyMembers.length > 0 && (
          <div className="mb-6 flex gap-3 items-center">
            <select
              value={selectedFamilyId}
              onChange={(e) => setSelectedFamilyId(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
            >
              <option value="">בחר בן משפחה להוספה...</option>
              {familyMembers
                .filter((f) => !participants.some((p) => p._id === f._id || p.familyMemberId === f._id))
                .map((f) => (
                  <option key={f._id} value={f._id}>
                    {f.name} {f.relation ? `(${f.relation})` : ""}
                  </option>
                ))}
            </select>
            <button
              onClick={handleAddFamily}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
            >
              ➕ הוסף לסדנה
            </button>
          </div>
        )}

        {message && (
          <p
            className={`mb-3 text-sm font-medium ${
              message.startsWith("✅") || message.startsWith("🚫")
                ? "text-green-600"
                : message.startsWith("⚠️")
                ? "text-amber-600"
                : "text-red-600"
            }`}
          >
            {message}
          </p>
        )}

        {loading ? (
          <p className="text-sm text-gray-600">⏳ טוען משתתפים...</p>
        ) : participants.length > 0 ? (
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
            {participants.map((p) =>
              editingUserId === p._id ? renderEditForm(p) : renderParticipant(p)
            )}
          </div>
        ) : (
          <p className="text-center text-gray-500">אין משתתפים רשומים עדיין.</p>
        )}
      </div>
    </div>
  );
}
