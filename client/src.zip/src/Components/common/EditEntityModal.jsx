export default function EditEntityModal({ entity, isFamily, onSave, onCancel }) {
  const [form, setForm] = useState(entity || {});
  const handleChange = (key, val) => setForm(p => ({ ...p, [key]: val }));

  return (
    <div className="p-4 space-y-3">
      {["name", "email", "phone", "city", "relation", "idNumber"].map(f => (
        <input
          key={f}
          value={form[f] || ""}
          onChange={e => handleChange(f, e.target.value)}
          placeholder={f}
          className="border px-3 py-2 rounded-lg w-full"
        />
      ))}
      <input
        type="date"
        value={form.birthDate?.split("T")[0] || ""}
        onChange={e => handleChange("birthDate", e.target.value)}
        className="border px-3 py-2 rounded-lg w-full"
      />
      {!isFamily && (
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={!!form.canCharge}
            onChange={e => handleChange("canCharge", e.target.checked)}
          />
          <span>הרשאה לגבייה</span>
        </label>
      )}
      <div className="flex justify-end gap-2">
        <button onClick={() => onCancel?.()} className="bg-gray-100 px-4 py-2 rounded-lg">בטל</button>
        <button onClick={() => onSave?.(form)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg">שמור</button>
      </div>
    </div>
  );
}
