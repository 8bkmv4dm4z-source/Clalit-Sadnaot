import React from "react";

/**
 * WaitPill
 * --------
 * A tiny pill component that displays a "typing…" indicator when
 * the user is currently typing into a search field.  Visibility
 * should be controlled by the parent via the `visible` prop.
 *
 * @param {boolean} visible Whether to display the pill
 */
export default function WaitPill({ visible = false }) {
  if (!visible) return null;
  return (
    <span
      className="ml-2 inline-block bg-gray-200 text-gray-600 rounded-full px-3 py-1 text-xs font-medium animate-pulse"
    >
      typing…
    </span>
  );
}