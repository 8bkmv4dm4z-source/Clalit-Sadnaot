import React, { createContext, useContext, useState } from "react";

/**
 * ViewContext
 * -----------------
 * Holds transient UI state used by views/pages such as search queries
 * and selected search fields.  This decouples quick UI changes
 * (like typing in a search bar) from business logic contexts such as
 * Auth or WorkshopContext.  Only lightweight state should live here.
 */
const ViewContext = createContext({
  searchQuery: "",
  setSearchQuery: () => {},
  searchBy: "all",
  setSearchBy: () => {},
});

export const ViewProvider = ({ children }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchBy, setSearchBy] = useState("all");

  return (
    <ViewContext.Provider
      value={{ searchQuery, setSearchQuery, searchBy, setSearchBy }}
    >
      {children}
    </ViewContext.Provider>
  );
};

export const useView = () => useContext(ViewContext);