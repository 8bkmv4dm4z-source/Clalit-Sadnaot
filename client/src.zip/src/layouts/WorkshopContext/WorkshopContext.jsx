/**
 * WorkshopContext.jsx — Server Source of Truth (no local mutations)
 * -----------------------------------------------------------------
 * 🧩 All updates come from server responses + refetches
 * 🧠 userWorkshopMap + familyWorkshopMap built only from fetches
 * 🔐 Uses apiFetch(); tokens/refresh handled by your util
 * ✅ Normalizes optional workshop fields safely for UI
 */

import React, { createContext, useContext, useEffect, useState, useRef } from "react";
import { useProfiles } from "../ProfileContext";
import { apiFetch } from "../../utils/apiFetch";

/* ───────────────────────── Debug Helpers ───────────────────────── */
// Allow enabling via query string: ?debug=ws
try {
  if (typeof window !== "undefined") {
    const q = new URLSearchParams(window.location.search);
    if (q.get("debug") === "ws") localStorage.setItem("DEBUG_WS", "1");
  }
} catch (_) {}

// Runtime-checked logger (reads localStorage each call)
const dbgCtx = (...args) => {
  try {
    if (typeof window !== "undefined" && localStorage.getItem("DEBUG_WS") === "1") {
      console.log("[WS-CTX]", ...args);
    }
  } catch (_) {}
};

const WorkshopContext = createContext();

const log = (msg, data) => {
  const now = new Date().toLocaleTimeString("he-IL");
  console.log(`%c[${now}] [WORKSHOP] ${msg}`, "color:#43a047;font-weight:bold;", data ?? "");
};

export const WorkshopProvider = ({ children }) => {
  const [workshops, setWorkshops] = useState([]);
  const [displayedWorkshops, setDisplayedWorkshops] = useState([]);
  const [registeredWorkshopIds, setRegisteredWorkshopIds] = useState([]);
  const [userWorkshopMap, setUserWorkshopMap] = useState({});   // { [workshopId]: true }
  const [familyWorkshopMap, setFamilyWorkshopMap] = useState({}); // { [workshopId]: [familyId,...] }
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [viewMode, setViewMode] = useState("all");
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);
  const fetchCooldown = useRef(false);

  const { fetchProfiles } = useProfiles();

  // One-time banner if debug is enabled
  useEffect(() => {
    try {
      if (typeof window !== "undefined" && localStorage.getItem("DEBUG_WS") === "1") {
        console.log("%c[WS-CTX] DEBUG ENABLED", "color:#2962ff;font-weight:bold");
      }
    } catch (_) {}
  }, []);

  const toId = (v) =>
    typeof v === "string"
      ? v
      : v?.familyMemberId
      ? String(v.familyMemberId)
      : String(v?._id ?? v ?? "");

  /* ============================================================
     📦 Fetch all workshops (source of truth)
  ============================================================ */
  // allow forced refetch that bypasses the cooldown
  // 1) Hoisted fetchers (no TDZ)
  async function fetchAllWorkshops(force = false) {
    if (fetchCooldown.current && !force) {
      log("⏳ Skipped fetchAllWorkshops due to cooldown");
      return;
    }
    fetchCooldown.current = true;
    setTimeout(() => (fetchCooldown.current = false), 1200);

    try {
      setLoading(true);
      setError(null);
      log("📡 Fetching all workshops...");
      dbgCtx("fetchAllWorkshops:start", { force });

      const res = await apiFetch(`/api/workshops`);
      const data = await res.json();
      dbgCtx("fetchAllWorkshops:raw-response", { ok: res.ok, keys: Object.keys(data || {}) });

      if (!res.ok) throw new Error(data.message || "Failed to fetch workshops");

      const workshopsArray = Array.isArray(data?.data)
        ? data.data
        : Array.isArray(data)
        ? data
        : [];

      dbgCtx("fetchAllWorkshops:array-size", { workshopsArrayLen: workshopsArray.length });

      const list = workshopsArray.map((w, idx) => {
        const normalized = {
  ...w,
  _id: String(w?._id ?? w?.id ?? ""),              // ← make workshop id a plain string
  address: w.address || "",
  city: w.city || "",
  studio: w.studio || "",
  coach: w.coach || "",
  participants: (w.participants || []).map(toId),
  familyRegistrations: w.familyRegistrations || [],
  userFamilyRegistrations: (w.userFamilyRegistrations || []).map(toId),
  waitingList: Array.isArray(w.waitingList) ? w.waitingList : [],
  maxParticipants: Number(w.maxParticipants ?? 0),
  waitingListMax: Number(w.waitingListMax ?? 0),
  isUserRegistered: !!w.isUserRegistered,
};


        const pLen = normalized.participants?.length ?? 0;
        const fLen = normalized.familyRegistrations?.length ?? 0;
        normalized.participantsCount =
          typeof w.participantsCount === "number" ? w.participantsCount : pLen + fLen;

        if (Array.isArray(w.familyRegistrations)) {
          normalized.userFamilyRegistrations = [
            ...new Set([
              ...normalized.userFamilyRegistrations,
              ...w.familyRegistrations.map((f) =>
                (f.familyMemberId?._id ?? f.familyMemberId ?? f?._id ?? "").toString()
              ),
            ]),
          ];
        }

        // 🔍 per-workshop log (safe + compact)
        dbgCtx("normalize", {
          i: idx,
          wid: String(normalized?._id || ""),
          title: normalized?.title,
          isUserRegistered: normalized.isUserRegistered,
          participantsLen: pLen,
          userFamilyRegsLen: normalized.userFamilyRegistrations.length,
          waitingListLen: normalized.waitingList.length,
        });

        return normalized;
      });

      // Build maps
      const userMap = {};
const familyMap = {};
for (const w of list) {
  // keep existing behavior
  if (w.isUserRegistered) userMap[w._id] = true;

  // ALSO infer from participants if server forgot the flag
  // NOTE: WorkshopContext doesn’t have `user` – if you can, inject currentUserId via prop
  if (!userMap[w._id] && currentUserId) {
    const inParticipants =
      Array.isArray(w.participants) &&
      w.participants.some(p => String(p?._id ?? p) === String(currentUserId));
    if (inParticipants) userMap[w._id] = true;
  }

  if (Array.isArray(w.userFamilyRegistrations) && w.userFamilyRegistrations.length) {
    familyMap[w._id] = w.userFamilyRegistrations;
  }
}


      dbgCtx("maps:built", {
        userWorkshopMapKeys: Object.keys(userMap).length,
        familyWorkshopMapKeys: Object.keys(familyMap).length,
      });
      dbgCtx("maps:built", {
  userWorkshopMapKeys: Object.keys(userMap),
  familyWorkshopMapKeys: Object.keys(familyMap),
});
dbgCtx("maps:samples", {
  userKeysSample: Object.keys(userMap).slice(0, 5),
  familyPairsSample: Object.entries(familyMap).slice(0, 3),
});



      setUserWorkshopMap(userMap);
      setFamilyWorkshopMap(familyMap);

      log(`✅ Workshops loaded (${list.length})`);
      dbgCtx("setState:workshops", { listLen: list.length });
      setWorkshops(list);
      setDisplayedWorkshops(list);

      return list;
    } catch (err) {
      console.error("❌ [WORKSHOP] fetchAllWorkshops error:", err);
      setError(err.message);
      dbgCtx("fetchAllWorkshops:error", { message: err.message });
    } finally {
      setLoading(false);
      dbgCtx("fetchAllWorkshops:done");
    }
  }

  async function fetchRegisteredWorkshops() {
    log("📡 Fetching registered workshops (ids)...");
    dbgCtx("fetchRegisteredWorkshops:start");
    try {
      setLoading(true);
      const res = await apiFetch(`/api/workshops/registered`);
      const regIds = await res.json();
      dbgCtx("fetchRegisteredWorkshops:raw-response", { ok: res.ok, type: Array.isArray(regIds) ? "array" : typeof regIds });

      if (!res.ok) throw new Error(regIds.message || "Failed to load registrations");
      const parsed = (Array.isArray(regIds) ? regIds : []).map((v) =>
        typeof v === "string" ? v : String(v?._id ?? v ?? "")
      );
      log(`✅ Registered workshops loaded (${parsed.length})`);
      dbgCtx("fetchRegisteredWorkshops:parsed", { count: parsed.length, sample: parsed.slice(0, 5) });
      setRegisteredWorkshopIds(parsed);
    } catch (err) {
      console.error("❌ [WORKSHOP] fetchRegisteredWorkshops error:", err);
      setError(err.message);
      dbgCtx("fetchRegisteredWorkshops:error", { message: err.message });
    } finally {
      setLoading(false);
      dbgCtx("fetchRegisteredWorkshops:done");
    }
  }

  function fetchWorkshops(force = false) {
    log("🔁 fetchWorkshops() called", { force });
    dbgCtx("fetchWorkshops:call", { force });
    return fetchAllWorkshops(force);
  }

  // 2) Place this AFTER the functions above
  useEffect(() => {
    log(`🔀 ViewMode → ${viewMode}`);
    dbgCtx("viewMode:effect", { viewMode });
    if (viewMode === "mine") {
      fetchRegisteredWorkshops();
    } else {
      fetchAllWorkshops();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewMode]);

  /* ============================================================
     🔧 Mutations (server-source-of-truth + refetch)
  ============================================================ */
  const deleteWorkshop = async (id) => {
    dbgCtx("deleteWorkshop:start", { id });
    try {
      const res = await apiFetch(`/api/workshops/${id}`, { method: "DELETE" });
      const data = await res.json();
      dbgCtx("deleteWorkshop:raw-response", { ok: res.ok });
      if (!res.ok) throw new Error(data.message || "Failed to delete workshop");
      await fetchAllWorkshops(true); // refresh from server
      dbgCtx("deleteWorkshop:success", { id });
      return { success: true, message: "Workshop deleted successfully" };
    } catch (err) {
      console.error("❌ deleteWorkshop error:", err);
      dbgCtx("deleteWorkshop:error", { id, message: err.message });
      return { success: false, message: err.message };
    }
  };

  const registerEntityToWorkshop = async (workshopId, familyId = null) => {
    dbgCtx("registerEntity:start", { workshopId, familyId });
    try {
      const res = await apiFetch(`/api/workshops/${workshopId}/register-entity`, {
        method: "POST",
        body: JSON.stringify({ familyId }),
      });
      const data = await res.json();
      dbgCtx("registerEntity:raw-response", { ok: res.ok, message: data?.message });

      if (!res.ok) throw new Error(data.message || "Failed to register");

      // always refetch; server is source of truth
      await fetchAllWorkshops(true);
      await fetchRegisteredWorkshops();
      await fetchProfiles();
      dbgCtx("registerEntity:success", { workshopId, familyId });
      return { success: true, data };
    } catch (err) {
      console.error("❌ registerEntityToWorkshop error:", err);
      dbgCtx("registerEntity:error", { workshopId, familyId, message: err.message });
      return { success: false, message: err.message };
    }
  };

  const unregisterEntityFromWorkshop = async (workshopId, familyId = null) => {
    dbgCtx("unregisterEntity:start", { workshopId, familyId });
    try {
      const res = await apiFetch(`/api/workshops/${workshopId}/unregister-entity`, {
        method: "DELETE",
        body: JSON.stringify(familyId ? { familyId } : {}),
      });
      const data = await res.json();
      dbgCtx("unregisterEntity:raw-response", { ok: res.ok, message: data?.message });

      if (!res.ok) throw new Error(data.message || "Failed to unregister");

      await fetchAllWorkshops(true);
      await fetchRegisteredWorkshops();
      await fetchProfiles();
      dbgCtx("unregisterEntity:success", { workshopId, familyId });
      return { success: true, data };
    } catch (err) {
      console.error("❌ unregisterEntityFromWorkshop error:", err);
      dbgCtx("unregisterEntity:error", { workshopId, familyId, message: err.message });
      return { success: false, message: err.message };
    }
  };

  const registerToWaitlist = async (workshopId, familyId = null) => {
    dbgCtx("waitlistRegister:start", { workshopId, familyId });
    try {
      const res = await apiFetch(`/api/workshops/${workshopId}/waitlist-entity`, {
        method: "POST",
        body: JSON.stringify({ familyId }),
      });
      const data = await res.json();
      dbgCtx("waitlistRegister:raw-response", { ok: res.ok, message: data?.message });

      if (!res.ok) throw new Error(data.message || "Failed to register to waitlist");

      await fetchAllWorkshops(true);
      await fetchRegisteredWorkshops();
      dbgCtx("waitlistRegister:success", { workshopId, familyId });
      return { success: true, data };
    } catch (err) {
      console.error("❌ registerToWaitlist error:", err);
      dbgCtx("waitlistRegister:error", { workshopId, familyId, message: err.message });
      return { success: false, message: err.message };
    }
  };

  const unregisterFromWaitlist = async (workshopId, familyId = null) => {
    dbgCtx("waitlistUnregister:start", { workshopId, familyId });
    try {
      const res = await apiFetch(`/api/workshops/${workshopId}/waitlist-entity`, {
        method: "DELETE",
        body: JSON.stringify(familyId ? { familyId } : {}),
      });
      const data = await res.json();
      dbgCtx("waitlistUnregister:raw-response", { ok: res.ok, message: data?.message });

      if (!res.ok) throw new Error(data.message || "Failed to remove from waitlist");

      await fetchAllWorkshops(true);
      await fetchRegisteredWorkshops();
      dbgCtx("waitlistUnregister:success", { workshopId, familyId });
      return { success: true, data };
    } catch (err) {
      console.error("❌ unregisterFromWaitlist error:", err);
      dbgCtx("waitlistUnregister:error", { workshopId, familyId, message: err.message });
      return { success: false, message: err.message };
    }
  };

  /* ============================================================
     🏙️ Utilities
  ============================================================ */
  const fetchAvailableCities = async () => {
    dbgCtx("fetchAvailableCities:start");
    try {
      const res = await apiFetch("/api/workshops/meta/cities");
    const data = await res.json();
      dbgCtx("fetchAvailableCities:raw-response", { ok: res.ok, keys: Object.keys(data || {}) });
      if (!res.ok) throw new Error(data.message || "Failed to fetch cities");
      const cities = data.cities || [];
      dbgCtx("fetchAvailableCities:success", { count: cities.length });
      return cities;
    } catch (err) {
      console.error("❌ fetchAvailableCities error:", err);
      dbgCtx("fetchAvailableCities:error", { message: err.message });
      return [];
    }
  };

  const validateAddress = async (city, address) => {
    dbgCtx("validateAddress:start", { city, address });
    try {
      const res = await apiFetch(
        `/api/workshops/validate-address?city=${encodeURIComponent(city)}&address=${encodeURIComponent(address)}`
      );
      const data = await res.json();
      dbgCtx("validateAddress:raw-response", { ok: res.ok, data });
      if (!res.ok) throw new Error(data.message || "Failed to validate address");
      dbgCtx("validateAddress:success");
      return data;
    } catch (err) {
      console.error("❌ validateAddress error:", err);
      dbgCtx("validateAddress:error", { message: err.message });
      return { success: false, message: err.message };
    }
  };

  /* ============================================================
     🧠 Provider
  ============================================================ */
  return (
    <WorkshopContext.Provider
      value={{
        workshops,
        displayedWorkshops,
        setDisplayedWorkshops,
        registeredWorkshopIds,
        setRegisteredWorkshopIds,
        userWorkshopMap,
        familyWorkshopMap,
        loading,
        error,
        viewMode,
        setViewMode,
        selectedWorkshop,
        setSelectedWorkshop,

        fetchWorkshops,
        fetchRegisteredWorkshops,

        deleteWorkshop,
        registerEntityToWorkshop,
        unregisterEntityFromWorkshop,
        registerToWaitlist,
        unregisterFromWaitlist,

        fetchAvailableCities,
        validateAddress,
      }}
    >
      {children}
    </WorkshopContext.Provider>
  );
};

export const useWorkshops = () => useContext(WorkshopContext);
