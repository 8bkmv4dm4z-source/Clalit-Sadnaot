import { useState, useEffect } from "react";

/**
 * useDebouncedValue
 * ------------------
 * Generic hook to debounce any value changes by a given delay.
 * Returns the debounced value which only updates after the
 * specified timeout has elapsed without further changes.
 *
 * @param {*} value The input value to debounce
 * @param {number} delay Delay in milliseconds (default: 350)
 * @returns {*} The debounced value
 */
export default function useDebouncedValue(value, delay = 350) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}